import pandas as pd
import streamlit as st
from scripts.search import search_image, search_gizi

st.title('Food Nutrition Search')

tab_image, tab_gizi = st.tabs(['Search by Image', 'Search by Gizi'])
with tab_image:
    uploaded_file = st.file_uploader("Choose a file")
    if uploaded_file:
        bytes_data = uploaded_file.getvalue()
        st.image(bytes_data)

    submit = st.button('Submit', type='primary', disabled=uploaded_file is None, key='search_image')
    if submit:
        image_result = search_image(bytes_data)
        st.session_state['image_result'] = image_result
    
    st.divider()
    st.header('Image Search Result')
    image_result = st.session_state.get('image_result', None)
    if image_result:
        st.json(image_result, expanded=False)
        df = pd.DataFrame(image_result)
        df = df[['image', 'name', 'fat', 'proteins', 'calories', 'carbohydrate']]
        st.dataframe(
            df,
            column_config={
                "image": st.column_config.ImageColumn(
                    "Image", help="Streamlit app preview screenshots"
                )
            },
        )
    
with tab_gizi:
    fat = st.text_input('Fat', value='0')
    proteins = st.text_input('Protein', value='0')
    calories = st.text_input('Kalori', value='0')
    carbohydrate = st.text_input('Karbohidrat', value='0')

    valid = False
    try:
        calories, proteins, fat, carbohydrate = [float(val) for val in [calories, proteins, fat, carbohydrate]]
        valid = True
        
    except:
        st.error('Value must be a float or number!')


    st.markdown(f'calories, proteins, fat, carbohydrate: {(calories, proteins, fat, carbohydrate)}')

    submit = st.button('Submit', type='primary', disabled=not valid, key='search_gizi')
    if submit:
        # Call OCR API
        gizi_result = search_gizi(calories, proteins, fat, carbohydrate)
        st.session_state['gizi_result'] = gizi_result
    
    st.divider()
    st.header('Gizi Search Result')
    gizi_result = st.session_state.get('gizi_result', None)
    if gizi_result:
        st.json(gizi_result, expanded=False)
        df = pd.DataFrame(gizi_result)
        df = df[['image', 'name', 'fat', 'proteins', 'calories', 'carbohydrate']]
        st.dataframe(
            df,
            column_config={
                "image": st.column_config.ImageColumn(
                    "Image", help="Streamlit app preview screenshots"
                )
            },
        )

